import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler, OneHotEncoder

from sklearn.compose import ColumnTransformer
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn.metrics import confusion_matrix, classification_report

import matplotlib.pyplot as plt
import numpy as np

import joblib

df_ori = pd.read_csv('adult.csv')

# 1. VER EL DATASET

# Para empezar debemos ver info de la data, por lo que se vee no tiene nulos

# print(df_ori.isna().sum())

# print(df_ori.head())

# Con esto estoy diciendo que todos los valores de ? los ponga nulos, porque en el dataset no hay nulos pero si ?
df_mod = pd.read_csv('adult.csv', na_values='?')

# Con esto veo que filas tienen valores nulos
# print(df_mod.isna().sum())

# Con esto en cambio saco un porsentaje de los valores nulos, como ninguno pasa el 6% vamos a remplazar por la media
# o por la moda, depende de si es texto no numero
# print((df_mod.isnull().mean() * 100).sort_values(ascending=False))

# 2. CAMBIAR LOS VALORES NULOS

# Esto es lo que va a cambiar el valor nulo, le estamos diciendo que sea por mas frecuente, y ocupamos el mimso en las 3
# porque las 3 columnas son variables categoricas
imputer = SimpleImputer(strategy='most_frequent')
# En ocupacion la mas frecuente es 'Prof-specialty' por lo que 2809 datos pasan de ? a Prof-specialty
df_mod[['occupation']] = imputer.fit_transform(df_mod[['occupation']])
# en workclass la mas frecuente es 'Private' por lo que 2799 datos ? pasan a ser Private
df_mod[['workclass']] = imputer.fit_transform(df_mod[['workclass']])
# en 'native-country' el mas frecuente es 'United-States' por lo que 857 ? pasan a ser United-States
df_mod[['native-country']] = imputer.fit_transform(df_mod[['native-country']])

# print((df_mod.isnull().mean() * 100).sort_values(ascending=False))

# Ocupe esto para ver los valores de cada uno, y compare como era el original y en el que reemplace
# print(df_ori['native-country'].value_counts())
# print(df_mod['native-country'].value_counts())

# 3. ELIMINAR DUPLICADOS

# Ahora despues de limpiar la data vamos a eliminar duplicados
# con duplicados me refiero a que toda la fila sea exactamente igual, no con que tenga un valor igual
# si los dejamos vamos a hacer que el mismo punto (vecino) tenga mas peso que los demas,
# Haciendo que el modelo capaz sea peor xd
# print(df_mod.duplicated().sum()) #aqui vemos los valores duplicados que son 53 y los voy a eliminar
df_mod = df_mod.drop_duplicates()

# 4. One Hot Encoding

# Cambiamos estos valoers por 1 y 0 si es mas de 50k es 1 y si es menor es 0
df_mod['income'] = df_mod['income'].map({
    '<=50K': 0,
    '>50K': 1
})
# print(df_mod['income'].value_counts())

# Lo mismo Female 0 y Male 1
df_mod['gender'] = df_mod['gender'].map({
    'Female': 0,
    'Male': 1
})

# Como en marital-status hay muchos valores les voy a poner en 4 nomas
df_mod['marital-status'] = df_mod['marital-status'].map({
    'Married-civ-spouse': 'Married',
    'Married-spouse-absent': 'Married',
    'Married-AF-spouse': 'Married',
    'Never-married': 'Single',
    'Divorced': 'Divorced',
    'Separated': 'Divorced',
    'Widowed': 'Widowed'
})

# print(df_mod['marital-status'].value_counts())

# Voy a hacer lo mismo para las ocupaciones

df_mod['occupation'] = df_mod['occupation'].map({
    'Prof-specialty': 'Professional',
    'Exec-managerial': 'Professional',
    'Tech-support': 'Professional',
    'Craft-repair': 'Manual',
    'Machine-op-inspct': 'Manual',
    'Farming-fishing': 'Manual',
    'Transport-moving': 'Manual',
    'Handlers-cleaners': 'Manual',
    'Other-service': 'Service',
    'Protective-serv': 'Service',
    'Priv-house-serv': 'Service',
    'Adm-clerical': 'Office',
    'Sales': 'Office',
})

# print(df_mod['occupation'].value_counts())

# 5. Separamos en la variable objetivo y las demas
x = df_mod.drop(columns=['education', 'income'])
y = df_mod['income']

# Como Knn mide distancias no podemos medir una variable categorica, por esto las dividimos en 2
categorical_cols = x.select_dtypes(include='object').columns
numeric_cols = x.select_dtypes(exclude='object').columns

# Veran mijos aqui estamos escalando las variables que son numeros porque si no se escalan los valores
# un valor de una columna tendra mas peso que el valor de otra columna porque solo va a ver el valor mas alto
# y eso hace que el modelo este malo por ese motivo se debe de escalar
preprocessor = ColumnTransformer(
    transformers=[
        ('num', StandardScaler(), numeric_cols),
        ('cat', OneHotEncoder(handle_unknown='ignore', sparse_output=False), categorical_cols)
    ]
)

# Este codigo de aqui es para ver el valor de k mas optimo, me dio que es 25 mas o menos
# si quieren probar el codigo, esperaran un buen rato, si demora xd

# k_valores = range(1,70)
# cv_scores = []

# for k in k_valores:
#     pipeline = Pipeline([
#         ('preprocess', preprocessor),
#         ('knn', KNeighborsClassifier(
#             n_neighbors=k,
#             metric='euclidean'
#         ))
#     ])
    
#     scores = cross_val_score(
#         pipeline,
#         x,
#         y,
#         cv=5,
#         scoring='f1'
#     )
    
#     cv_scores.append(scores.mean())

# k_optimo = k_valores[np.argmax(cv_scores)]
# print(f'El valor óptimo de k es: {k_optimo}')

# plt.plot(k_valores, cv_scores)
# plt.xlabel('Valor de k')
# plt.ylabel('Precisión de la validacion cruzada')
# plt.title('Seleccion del valor de k')
# plt.show()

# ya se la saben mijos dividimos los test
x_train, x_test, y_train, y_test = train_test_split(
    x,
    y,
    test_size=0.2,
    stratify=y,
    random_state=73
)

# Este pipeline es como para indicar que se debe de hacer, aqui le decimos que primero haga lo de
# separar las variables numericas y categoricas, para poder escalar las numeriacs y ahi si hacer
# el entrenamiento del modelo

pipeline = Pipeline([
    ('preprocess', preprocessor),
    ('knn', KNeighborsClassifier(n_neighbors=25, metric='manhattan'))
])

# euclidean 0.850 (redondeado), manhattan 0.850, minkowski 0.850(redondeado), cosine 0.848 (la peor)
# En teoria creo que manhattan es la mejor, por poco, porque todos estan ahi ahi, pero si quieren pueden probar

pipeline.fit(x_train, y_train)

y_pred = pipeline.predict(x_test)

cm = confusion_matrix(y_test, y_pred)
print(cm)

print("Exactitud (accuracy):", pipeline.score(x_test, y_test))

print(classification_report(y_test, y_pred))

joblib.dump(pipeline, "modeloKNN_entrenado.pkl")

# Bueno mi trabajo a culminado, y como solo vivo para hacer deberes y pajas... y ya no tengo deberes... ʕ •ᴥ•ʔ
# ( ≖ᴗ≖​)
# PD: leeran el puto readme.txt